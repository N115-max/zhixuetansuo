@echo off
chcp 65001 >nul
cd /d %~dp0
where node >nul 2>nul
if errorlevel 1 (
  echo 还没有安装 Node.js。
  echo 请先打开 https://nodejs.org/zh-cn 下载 LTS 版本，安装后再双击本文件。
  pause
  exit /b
)
echo 正在启动智学探索...
start "" http://localhost:3000
node server.js
pause
